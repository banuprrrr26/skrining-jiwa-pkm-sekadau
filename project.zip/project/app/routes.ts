import { type RouteConfig, index, route, layout } from "@react-router/dev/routes";

export default [
  index("routes/home.tsx"),
  layout("routes/screening/layout.tsx", [
    route("screening/demographic", "routes/screening/demographic.tsx"),
    route("screening/mmys", "routes/screening/mmys.tsx"),
    route("screening/phq4", "routes/screening/phq4.tsx"),
    route("screening/epds", "routes/screening/epds.tsx"),
    route("screening/result", "routes/screening/result.tsx"),
  ]),
  route("admin/login", "routes/admin/login.tsx"),
  route("admin/dashboard", "routes/admin/dashboard.tsx"),
  route("admin/patients", "routes/admin/patients.tsx"),
  route("admin/patient-detail", "routes/admin/patient-detail.tsx"),
  route("api/screening", "routes/api/screening.tsx"),
] satisfies RouteConfig;
