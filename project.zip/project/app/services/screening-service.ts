import { supabase } from "~/lib/supabase.server";

export interface ScreeningRow {
  id: number;
  created_at: string;
  nama: string;
  nik: string;
  tgl_lahir: string | null;
  usia: number | null;
  jenis_kelamin: string | null;
  alamat: string | null;
  desa: string | null;
  kecamatan: string | null;
  pendidikan: string | null;
  pekerjaan: string | null;
  no_hp: string | null;
  status_hamil_nifas: boolean | null;
  jenis_instrumen: string | null;
  skor_total: number | null;
  skor_sub_anxietas: number | null;
  skor_sub_depresi: number | null;
  interpretasi: string | null;
  rekomendasi: string | null;
  risiko_tinggi_suicide: boolean | null;
  detail_jawaban: Record<string, unknown> | null;
}

export interface InsertScreeningData {
  nama: string;
  nik: string;
  tgl_lahir?: string;
  usia?: number;
  jenis_kelamin?: string;
  alamat?: string;
  desa?: string;
  kecamatan?: string;
  pendidikan?: string;
  pekerjaan?: string;
  no_hp?: string;
  status_hamil_nifas?: boolean;
  jenis_instrumen?: string;
  skor_total?: number;
  skor_sub_anxietas?: number;
  skor_sub_depresi?: number;
  interpretasi?: string;
  rekomendasi?: string;
  risiko_tinggi_suicide?: boolean;
  detail_jawaban?: Record<string, unknown>;
}

export interface DateRange {
  from?: string; // ISO date string e.g. "2025-01-01"
  to?: string;   // ISO date string e.g. "2025-12-31"
}

/** Insert a new screening result and return the created row */
export async function insertScreening(data: InsertScreeningData): Promise<ScreeningRow> {
  const { data: row, error } = await supabase
    .from("screenings")
    .insert(data)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to insert screening: ${error.message}`);
  }

  return row as ScreeningRow;
}

/** Fetch a single screening by ID */
export async function getScreeningById(id: number): Promise<ScreeningRow | null> {
  const { data, error } = await supabase
    .from("screenings")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    if (error.code === "PGRST116") return null; // not found
    throw new Error(`Failed to fetch screening: ${error.message}`);
  }

  return data as ScreeningRow;
}

/** Fetch all screenings filtered by instrument type, with optional date range */
export async function getScreeningsByType(type: string, dateRange?: DateRange): Promise<ScreeningRow[]> {
  let query = supabase
    .from("screenings")
    .select("*")
    .eq("jenis_instrumen", type);

  if (dateRange?.from) {
    query = query.gte("created_at", `${dateRange.from}T00:00:00.000Z`);
  }
  if (dateRange?.to) {
    query = query.lte("created_at", `${dateRange.to}T23:59:59.999Z`);
  }

  const { data, error } = await query.order("created_at", { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch screenings: ${error.message}`);
  }

  return (data ?? []) as ScreeningRow[];
}

/** Fetch all screenings */
export async function getAllScreenings(): Promise<ScreeningRow[]> {
  const { data, error } = await supabase
    .from("screenings")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch screenings: ${error.message}`);
  }

  return (data ?? []) as ScreeningRow[];
}

/** Delete a screening by ID */
export async function deleteScreening(id: number): Promise<void> {
  const { error } = await supabase
    .from("screenings")
    .delete()
    .eq("id", id);

  if (error) {
    throw new Error(`Failed to delete screening: ${error.message}`);
  }
}

/** Get counts grouped by instrument type, with optional date range */
export async function getScreeningCounts(dateRange?: DateRange): Promise<Record<string, number>> {
  let query = supabase
    .from("screenings")
    .select("jenis_instrumen");

  if (dateRange?.from) {
    query = query.gte("created_at", `${dateRange.from}T00:00:00.000Z`);
  }
  if (dateRange?.to) {
    query = query.lte("created_at", `${dateRange.to}T23:59:59.999Z`);
  }

  const { data, error } = await query;

  if (error) {
    throw new Error(`Failed to fetch counts: ${error.message}`);
  }

  const counts: Record<string, number> = {
    MMYS_7_9: 0,
    MMYS_10_18: 0,
    PHQ4: 0,
    EPDS: 0,
  };

  for (const row of data ?? []) {
    const type = row.jenis_instrumen;
    if (type && type in counts) {
      counts[type]++;
    }
  }

  return counts;
}
