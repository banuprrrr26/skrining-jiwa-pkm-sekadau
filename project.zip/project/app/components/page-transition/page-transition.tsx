import { useLocation } from "react-router";
import { useRef, useEffect, useState } from "react";
import styles from "./page-transition.module.css";

interface PageTransitionProps {
  children: React.ReactNode;
  className?: string;
}

export function PageTransition({ children, className }: PageTransitionProps) {
  const location = useLocation();
  const [animKey, setAnimKey] = useState(location.key);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setAnimKey(location.key);
  }, [location.key]);

  return (
    <div
      ref={ref}
      key={animKey}
      className={`${styles.enter}${className ? ` ${className}` : ""}`}
    >
      {children}
    </div>
  );
}
