import { useNavigation } from "react-router";
import styles from "./nav-progress.module.css";

export function NavProgress() {
  const navigation = useNavigation();
  const isNavigating = navigation.state !== "idle";

  if (!isNavigating) return null;

  return <div className={styles.bar} />;
}
