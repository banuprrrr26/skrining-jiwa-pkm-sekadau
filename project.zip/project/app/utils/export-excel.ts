import type { ScreeningRow } from "~/services/screening-service";

const SCREENING_LABELS: Record<string, string> = {
  MMYS_7_9: "MMYS V.1 — Anak (7-9 tahun)",
  MMYS_10_18: "MMYS V.1 — Remaja (10-18 tahun)",
  PHQ4: "PHQ-4 — Dewasa (≥18 tahun)",
  EPDS: "EPDS — Ibu Hamil/Nifas",
};

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

/** Build screening table rows for Excel export */
export function buildScreeningExcelData(patients: ScreeningRow[], type: string) {
  return patients.map((p, i) => ({
    No: i + 1,
    "Nama Lengkap": p.nama,
    NIK: p.nik,
    "Tanggal Lahir": p.tgl_lahir ?? "-",
    Usia: p.usia ?? "-",
    "Jenis Kelamin": p.jenis_kelamin ?? "-",
    Alamat: p.alamat ?? "-",
    Desa: p.desa ?? "-",
    Kecamatan: p.kecamatan ?? "-",
    Pendidikan: p.pendidikan ?? "-",
    Pekerjaan: p.pekerjaan ?? "-",
    "No HP": p.no_hp ?? "-",
    "Tanggal Skrining": formatDate(p.created_at),
    ...getScoreColumns(p, type),
    Interpretasi: p.interpretasi ?? "-",
    Rekomendasi: p.rekomendasi ?? "-",
  }));
}

function getScoreColumns(p: ScreeningRow, type: string): Record<string, string | number> {
  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    return {
      "Skor Anxietas": `${p.skor_sub_anxietas ?? 0}/3`,
      "Skor Depresi": `${p.skor_sub_depresi ?? 0}/3`,
    };
  }
  if (type === "PHQ4") {
    return {
      "PHQ-2 (Depresi)": `${p.skor_sub_depresi ?? 0}/6`,
      "GAD-2 (Kecemasan)": `${p.skor_sub_anxietas ?? 0}/6`,
    };
  }
  if (type === "EPDS") {
    return {
      "Skor EPDS": `${p.skor_total ?? 0}/30`,
      "Risiko Bunuh Diri": p.risiko_tinggi_suicide ? "Ya" : "Tidak",
    };
  }
  return {};
}

export function getExcelFilename(type: string, prefix = "Data_Skrining"): string {
  const label = SCREENING_LABELS[type]?.replace(/[^a-zA-Z0-9]/g, "_") ?? type;
  const date = new Date().toISOString().split("T")[0];
  return `${prefix}_${label}_${date}.xlsx`;
}
