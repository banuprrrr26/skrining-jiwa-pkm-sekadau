import type { MMYSAnswer, PHQ4Answer, EPDSAnswer, ScreeningType } from "~/data/mock-patients";

export interface MMYSScores {
  anxietasScore: number;
  depresiScore: number;
}

export interface PHQ4Scores {
  phq2Score: number;
  gad2Score: number;
}

export interface EPDSScores {
  epdsScore: number;
}

// MMYS V.1 Scoring
export function calculateMMYSScores(answers: MMYSAnswer): MMYSScores {
  const anxietasScore = (answers.anxietas1 ? 1 : 0) + (answers.anxietas2 ? 1 : 0) + (answers.anxietas3 ? 1 : 0);
  const depresiScore = (answers.depresi1 ? 1 : 0) + (answers.depresi2 ? 1 : 0) + (answers.depresi3 ? 1 : 0);

  return { anxietasScore, depresiScore };
}

/**
 * Interpretasi MMYS V.1 berdasarkan pedoman:
 *
 * Pertanyaan 1 dan 3 adalah pertanyaan KUNCI.
 * Pertanyaan 2 adalah pertanyaan netral.
 *
 * Skala A (Anxietas) — anxietas1, anxietas2, anxietas3:
 * - Tidak gejala: Semua "Tidak", ATAU hanya pertanyaan 2 yang "Ya"
 * - Gejala ringan: Salah satu pertanyaan 1 ATAU 3 yang "Ya" (tapi bukan keduanya)
 * - Gejala berat: Pertanyaan 1 DAN 3 keduanya "Ya"
 *
 * Skala B (Depresi) — depresi1, depresi2, depresi3: Sama logikanya.
 */
export function interpretMMYS(
  scores: MMYSScores,
  answers: MMYSAnswer,
): {
  anxietasInterpretation: string;
  depresiInterpretation: string;
  recommendation: string;
} {
  // --- Anxietas interpretation ---
  const anx1 = answers.anxietas1; // pertanyaan kunci 1
  const anx3 = answers.anxietas3; // pertanyaan kunci 3
  const anxBothKey = anx1 && anx3;
  const anxOneKey = (anx1 || anx3) && !anxBothKey;

  let anxietasInterpretation: string;
  let anxietasLevel: "none" | "mild" | "severe";

  if (anxBothKey) {
    // "Ya" pada pertanyaan 1 & 3 → gejala berat
    anxietasInterpretation = "Menunjukkan kemungkinan gejala anxietas berat";
    anxietasLevel = "severe";
  } else if (anxOneKey) {
    // Salah satu "Ya" pada pertanyaan 1 atau 3 → gejala ringan
    anxietasInterpretation = "Menunjukkan kemungkinan gejala anxietas ringan";
    anxietasLevel = "mild";
  } else {
    // Semua "Tidak" atau hanya pertanyaan 2 "Ya" → tidak gejala
    anxietasInterpretation = "Tidak menunjukkan kemungkinan gejala ansietas";
    anxietasLevel = "none";
  }

  // --- Depresi interpretation ---
  const dep1 = answers.depresi1; // pertanyaan kunci 1
  const dep3 = answers.depresi3; // pertanyaan kunci 3
  const depBothKey = dep1 && dep3;
  const depOneKey = (dep1 || dep3) && !depBothKey;

  let depresiInterpretation: string;
  let depresiLevel: "none" | "mild" | "severe";

  if (depBothKey) {
    depresiInterpretation = "Menunjukkan kemungkinan gejala depresi berat";
    depresiLevel = "severe";
  } else if (depOneKey) {
    depresiInterpretation = "Menunjukkan kemungkinan gejala depresi ringan";
    depresiLevel = "mild";
  } else {
    depresiInterpretation = "Tidak menunjukkan kemungkinan gejala depresi";
    depresiLevel = "none";
  }

  // --- Recommendation ---
  const hasSevere = anxietasLevel === "severe" || depresiLevel === "severe";
  const hasMild = anxietasLevel === "mild" || depresiLevel === "mild";

  let recommendation: string;

  if (hasSevere) {
    recommendation =
      "Konseling awal, diagnosis keperawatan dan asuhan keperawatan jiwa, tatalaksana medis, assessment dan tatalaksana psikologis, pemeriksaan lanjut untuk menegakkan diagnosa awal. Rujuk ke FKTL jika gejala berat atau indikasi membahayakan diri sendiri/orang lain";
  } else if (hasMild) {
    recommendation =
      "Konseling awal, diagnosis keperawatan dan asuhan keperawatan jiwa, tatalaksana medis, assessment dan tatalaksana psikologis, pemeriksaan lanjut untuk menegakkan diagnosa awal";
  } else {
    recommendation =
      "Edukasi kesehatan jiwa, penguatan faktor protektif (terlibat dalam kegiatan ekstrakurikuler, melakukan hobi yang positif, menjaga relasi sosial), peningkatan kemampuan life skill, pemeriksaan berkala 1x/tahun";
  }

  return { anxietasInterpretation, depresiInterpretation, recommendation };
}

// PHQ-4 Scoring
export function calculatePHQ4Scores(answers: PHQ4Answer): PHQ4Scores {
  const phq2Score = answers.q1 + answers.q2;
  const gad2Score = answers.q3 + answers.q4;

  return { phq2Score, gad2Score };
}

export function interpretPHQ4(scores: PHQ4Scores): {
  phq2Interpretation: string;
  gad2Interpretation: string;
  recommendation: string;
} {
  const phq2Interpretation =
    scores.phq2Score < 3 ? "Tidak ada gejala signifikan depresi" : "Menunjukkan kemungkinan gejala depresi";

  const gad2Interpretation =
    scores.gad2Score < 3 ? "Tidak ada gejala signifikan kecemasan" : "Menunjukkan kemungkinan gejala kecemasan";

  const hasSymptoms = scores.phq2Score >= 3 || scores.gad2Score >= 3;

  const recommendation = hasSymptoms
    ? "Konseling awal, pemeriksaan kesehatan jiwa untuk menegakkan diagnosis medis, tata laksana sesuai dengan kompetensi tenaga medis dan tenaga kesehatan puskesmas. Rujuk ke FKTL jika depresi berat atau indikasi membahayakan diri sendiri/orang lain, atau gejala kecemasan tidak membaik >1 bulan pasca konseling/tata laksana"
    : "Edukasi Kesehatan Jiwa: tanda sehat jiwa, faktor protektif sehat jiwa, manajemen dan coping stress, Pertolongan Pertama Pada Luka Psikologis (P3LP)";

  return { phq2Interpretation, gad2Interpretation, recommendation };
}

// EPDS Scoring
export function calculateEPDSScore(answers: EPDSAnswer): EPDSScores {
  // Q1, Q2, Q4: scored 0-3 (top to bottom)
  // Q3, Q5-Q10: reverse scored 3-0 (top to bottom)
  const score =
    answers.q1 +
    answers.q2 +
    (3 - answers.q3) +
    answers.q4 +
    (3 - answers.q5) +
    (3 - answers.q6) +
    (3 - answers.q7) +
    (3 - answers.q8) +
    (3 - answers.q9) +
    (3 - answers.q10);

  return { epdsScore: score };
}

export function interpretEPDS(
  scores: EPDSScores,
  q10Answer: number,
): { interpretation: string; recommendation: string } {
  const interpretation =
    scores.epdsScore < 13
      ? "Tidak menunjukkan gejala signifikan"
      : "Terindikasi/menunjukkan kemungkinan gejala depresi";

  const hasSymptoms = scores.epdsScore >= 13 || q10Answer >= 1;

  const recommendation = hasSymptoms
    ? "Konseling awal, pemeriksaan kesehatan jiwa untuk menegakkan diagnosis, tata laksana sesuai dengan kompetensi tenaga medis dan tenaga kesehatan puskesmas. Rujuk ke FKTL jika depresi berat atau indikasi membahayakan diri sendiri atau orang lain"
    : "Edukasi Kesehatan Jiwa: tanda sehat jiwa pada Ibu, faktor protektif sehat jiwa, latihan manajemen dan coping stress, pengasuhan positif";

  return { interpretation, recommendation };
}

export function determineScreeningType(age: number, gender: string, isPregnantOrPostpartum?: boolean): ScreeningType {
  if (isPregnantOrPostpartum && gender === "Perempuan" && age > 12) {
    return "EPDS";
  }

  if (age >= 7 && age <= 9) {
    return "MMYS_7_9";
  }

  if (age >= 10 && age <= 18) {
    return "MMYS_10_18";
  }

  return "PHQ4";
}
