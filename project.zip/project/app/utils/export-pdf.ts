import type { ScreeningRow } from "~/services/screening-service";
import {
  mmysAnxietasQuestions,
  mmysDepresiQuestions,
  phq4Questions,
  phq4Options,
  epdsQuestions,
} from "~/data/screening-questions";

const SCREENING_LABELS: Record<string, string> = {
  MMYS_7_9: "MMYS V.1 (Anak 7-9 tahun)",
  MMYS_10_18: "MMYS V.1 (Remaja 10-18 tahun)",
  PHQ4: "PHQ-4 (Dewasa ≥18 tahun)",
  EPDS: "EPDS (Ibu Hamil/Nifas)",
};

// Teal accent color matching the web UI
const TEAL: [number, number, number] = [18, 165, 148];
const TEAL_LIGHT: [number, number, number] = [240, 253, 250];
const BORDER_COLOR: [number, number, number] = [200, 220, 215];
const GRAY_LABEL: [number, number, number] = [120, 130, 128];
const DARK_TEXT: [number, number, number] = [30, 30, 30];

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

function getDetailValue(screening: ScreeningRow, key: string): string | null {
  const detail = screening.detail_jawaban as Record<string, unknown> | null;
  if (!detail) return null;
  const val = detail[key];
  return typeof val === "string" ? val : null;
}

type JsPDF = InstanceType<typeof import("jspdf").jsPDF>;

/** Check if we need a page break; if so, add a page and return new Y */
function ensureSpace(doc: JsPDF, y: number, neededHeight: number, margin: number): number {
  const pageHeight = doc.internal.pageSize.getHeight();
  if (y + neededHeight > pageHeight - margin) {
    doc.addPage();
    return margin;
  }
  return y;
}

/** Draw a section heading in teal */
function drawSectionHeading(doc: JsPDF, text: string, y: number, margin: number): number {
  y = ensureSpace(doc, y, 14, margin);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...TEAL);
  doc.text(text, margin, y);
  y += 8;
  return y;
}

/** Draw the demographic grid (2 columns, label + value pairs) */
function drawDemographicGrid(
  doc: JsPDF,
  screening: ScreeningRow,
  y: number,
  margin: number
): number {
  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - margin * 2;
  const colWidth = contentWidth / 2;
  const cellPadding = 4;
  const labelHeight = 4;
  const valueHeight = 6;
  const rowHeight = labelHeight + valueHeight + cellPadding * 2 + 2;

  const tanggalSkrining = getDetailValue(screening, "tanggal_skrining") ?? formatDate(screening.created_at);
  const tempatSkrining = getDetailValue(screening, "tempat_skrining") ?? "-";

  // Build pairs for the grid [label, value]
  const pairs: Array<[string, string]> = [
    ["NIK", screening.nik],
    ["TANGGAL LAHIR", screening.tgl_lahir ?? "-"],
    ["USIA", screening.usia ? `${screening.usia} tahun` : "-"],
    ["JENIS KELAMIN", screening.jenis_kelamin ?? "-"],
    ["ALAMAT", screening.alamat ?? "-"],
    ["DESA", screening.desa ?? "-"],
    ["KECAMATAN", screening.kecamatan ?? "-"],
    ["PENDIDIKAN", screening.pendidikan ?? "-"],
    ["PEKERJAAN", screening.pekerjaan ?? "-"],
    ["NOMOR HP", screening.no_hp ?? "-"],
    ["TANGGAL SKRINING", tanggalSkrining],
    ["TEMPAT SKRINING", tempatSkrining],
  ];

  if (screening.status_hamil_nifas !== null) {
    pairs.push(["HAMILNIFAS", screening.status_hamil_nifas ? "Ya" : "Tidak"]);
  }

  pairs.push(["JENIS SKRINING", SCREENING_LABELS[screening.jenis_instrumen ?? ""] ?? screening.jenis_instrumen ?? "-"]);

  // Draw bordered box around entire grid
  const numRows = Math.ceil(pairs.length / 2);
  const totalGridHeight = numRows * rowHeight;

  y = ensureSpace(doc, y, totalGridHeight + 4, margin);

  // Draw outer border
  doc.setDrawColor(...BORDER_COLOR);
  doc.setLineWidth(0.5);
  doc.roundedRect(margin, y, contentWidth, totalGridHeight, 2, 2, "S");

  // Draw grid lines
  for (let row = 1; row < numRows; row++) {
    const lineY = y + row * rowHeight;
    doc.line(margin, lineY, margin + contentWidth, lineY);
  }
  // Vertical middle line
  doc.line(margin + colWidth, y, margin + colWidth, y + totalGridHeight);

  // Fill cell content
  for (let i = 0; i < pairs.length; i++) {
    const [label, value] = pairs[i];
    const row = Math.floor(i / 2);
    const col = i % 2;
    const cellX = margin + col * colWidth + cellPadding;
    const cellY = y + row * rowHeight + cellPadding;

    // Label (small, uppercase, gray)
    doc.setFontSize(6.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...GRAY_LABEL);
    doc.text(label, cellX, cellY + 3);

    // Value (larger, bold, dark)
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...DARK_TEXT);
    doc.text(value, cellX, cellY + 3 + labelHeight + 4);
  }

  return y + totalGridHeight + 8;
}

/** Draw questionnaire answers section */
function drawAnswersSection(
  doc: JsPDF,
  screening: ScreeningRow,
  y: number,
  margin: number
): number {
  const type = screening.jenis_instrumen;
  const detail = screening.detail_jawaban as Record<string, unknown> | null;
  const answers = detail?.answers as Record<string, unknown> | null;
  if (!answers) return y;

  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - margin * 2;

  type QARow = { question: string; answer: string };
  const qaRows: QARow[] = [];

  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    mmysAnxietasQuestions.forEach((q, i) => {
      qaRows.push({ question: `A${i + 1}: ${q.text}`, answer: answers[q.id] ? "Ya" : "Tidak" });
    });
    mmysDepresiQuestions.forEach((q, i) => {
      qaRows.push({ question: `B${i + 1}: ${q.text}`, answer: answers[q.id] ? "Ya" : "Tidak" });
    });
  } else if (type === "PHQ4") {
    phq4Questions.forEach((q, i) => {
      const val = answers[q.id] as number;
      const label = phq4Options.find((o) => o.value === val)?.label || String(val);
      qaRows.push({ question: `Q${i + 1}: ${q.text}`, answer: `${label} (${val})` });
    });
  } else if (type === "EPDS") {
    epdsQuestions.forEach((q, i) => {
      const val = answers[q.id] as number;
      const optLabel = q.options.find((o) => o.value === val)?.label || String(val);
      qaRows.push({ question: `Q${i + 1}: ${q.text}`, answer: `${optLabel} (${val})` });
    });
  }

  if (qaRows.length === 0) return y;

  y = drawSectionHeading(doc, "Jawaban Kuesioner", y, margin);

  const rowPadding = 5;
  const rowMinHeight = 12;

  // Draw bordered box with rows
  y = ensureSpace(doc, y, qaRows.length * rowMinHeight + 4, margin);

  const startBoxY = y;
  let currentY = y;

  for (let i = 0; i < qaRows.length; i++) {
    const { question, answer } = qaRows[i];

    // Check for page break mid-rows
    currentY = ensureSpace(doc, currentY, rowMinHeight + 2, margin);
    if (currentY < startBoxY && i > 0) {
      // We jumped to a new page — close previous box
    }

    const questionMaxWidth = contentWidth * 0.65 - rowPadding * 2;
    const answerMaxWidth = contentWidth * 0.35 - rowPadding * 2;

    // Calculate text height
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    const questionLines = doc.splitTextToSize(question, questionMaxWidth);
    doc.setFont("helvetica", "bold");
    const answerLines = doc.splitTextToSize(answer, answerMaxWidth);
    const textHeight = Math.max(questionLines.length, answerLines.length) * 4.5;
    const actualRowHeight = Math.max(rowMinHeight, textHeight + rowPadding * 2);

    currentY = ensureSpace(doc, currentY, actualRowHeight, margin);

    // Row background (alternate)
    if (i % 2 === 0) {
      doc.setFillColor(...TEAL_LIGHT);
      doc.rect(margin, currentY, contentWidth, actualRowHeight, "F");
    }

    // Row border
    doc.setDrawColor(...BORDER_COLOR);
    doc.setLineWidth(0.3);
    doc.rect(margin, currentY, contentWidth, actualRowHeight, "S");

    // Question text
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...DARK_TEXT);
    const qTextY = currentY + rowPadding + 3;
    doc.text(questionLines, margin + rowPadding, qTextY);

    // Answer text (right-aligned, teal color)
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...TEAL);
    const answerX = margin + contentWidth - rowPadding;
    doc.text(answerLines, answerX, qTextY, { align: "right" });

    currentY += actualRowHeight;
  }

  return currentY + 8;
}

/** Draw score boxes */
function drawScoreSection(
  doc: JsPDF,
  screening: ScreeningRow,
  y: number,
  margin: number
): number {
  const type = screening.jenis_instrumen;
  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - margin * 2;

  type ScoreItem = { label: string; value: string };
  const scores: ScoreItem[] = [];

  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    scores.push(
      { label: "Skor Anxietas", value: `${screening.skor_sub_anxietas ?? 0}/3` },
      { label: "Skor Depresi", value: `${screening.skor_sub_depresi ?? 0}/3` }
    );
  } else if (type === "PHQ4") {
    scores.push(
      { label: "PHQ-2 (Depresi)", value: `${screening.skor_sub_depresi ?? 0}/6` },
      { label: "GAD-2 (Kecemasan)", value: `${screening.skor_sub_anxietas ?? 0}/6` }
    );
  } else if (type === "EPDS") {
    scores.push(
      { label: "Skor EPDS", value: `${screening.skor_total ?? 0}/30` },
      { label: "Risiko Bunuh Diri", value: screening.risiko_tinggi_suicide ? "Ya" : "Tidak" }
    );
  }

  if (scores.length === 0) return y;

  y = drawSectionHeading(doc, "Skor", y, margin);

  const boxHeight = 36;
  const gap = 6;
  const boxWidth = (contentWidth - gap * (scores.length - 1)) / scores.length;

  y = ensureSpace(doc, y, boxHeight + 8, margin);

  for (let i = 0; i < scores.length; i++) {
    const boxX = margin + i * (boxWidth + gap);

    // Box background
    doc.setFillColor(...TEAL_LIGHT);
    doc.setDrawColor(...BORDER_COLOR);
    doc.setLineWidth(0.5);
    doc.roundedRect(boxX, y, boxWidth, boxHeight, 2, 2, "FD");

    // Label (small, teal, centered at top)
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...TEAL);
    doc.text(scores[i].label, boxX + boxWidth / 2, y + 10, { align: "center" });

    // Score value (large, bold, centered)
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...TEAL);
    doc.text(scores[i].value, boxX + boxWidth / 2, y + 28, { align: "center" });
  }

  return y + boxHeight + 10;
}

/** Draw a bordered text box with left teal accent border */
function drawAccentBox(
  doc: JsPDF,
  text: string,
  y: number,
  margin: number
): number {
  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - margin * 2;
  const padding = 6;
  const accentWidth = 3;
  const maxTextWidth = contentWidth - accentWidth - padding * 2;

  doc.setFontSize(9.5);
  doc.setFont("helvetica", "normal");
  const lines = doc.splitTextToSize(text, maxTextWidth);
  const textHeight = lines.length * 5;
  const boxHeight = Math.max(20, textHeight + padding * 2);

  y = ensureSpace(doc, y, boxHeight + 4, margin);

  // Outer border
  doc.setDrawColor(...BORDER_COLOR);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin, y, contentWidth, boxHeight, 2, 2, "S");

  // Left accent bar
  doc.setFillColor(...TEAL);
  doc.rect(margin, y, accentWidth, boxHeight, "F");

  // Text
  doc.setTextColor(...DARK_TEXT);
  doc.text(lines, margin + accentWidth + padding, y + padding + 4);

  return y + boxHeight + 8;
}

/** Shared PDF header */
function renderPdfHeader(doc: JsPDF, title: string): number {
  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFillColor(...TEAL);
  doc.rect(0, 0, pageWidth, 28, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text(title, pageWidth / 2, 12, { align: "center" });
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("Sistem Skrining Kesehatan Jiwa Dinamis (SSKJD)", pageWidth / 2, 20, { align: "center" });

  doc.setTextColor(0, 0, 0);
  return 36;
}

/** Shared PDF footer */
function renderPdfFooter(doc: JsPDF, y: number, margin: number): void {
  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  doc.setFontSize(8);
  doc.setFont("helvetica", "italic");
  doc.setTextColor(120, 120, 120);
  doc.text(
    `Dicetak pada: ${new Date().toLocaleDateString("id-ID", {
      day: "2-digit",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })}`,
    margin,
    y
  );
  doc.text("SSKJD — Sistem Skrining Kesehatan Jiwa Dinamis", pageWidth - margin, y, { align: "right" });
}

/**
 * Generate a screening result PDF matching the web page visual layout:
 * - Demographics in a 2-column grid card
 * - Questionnaire answers as bordered rows (question left, answer right in teal)
 * - Score boxes (large numbers)
 * - Interpretation and recommendation in accent-bordered boxes
 */
export async function generateScreeningResultPdf(screening: ScreeningRow): Promise<void> {
  const { default: jsPDF } = await import("jspdf");

  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const margin = 14;

  // Header
  let y = renderPdfHeader(doc, "LAPORAN HASIL SKRINING KESEHATAN JIWA");

  // Patient name subtitle
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...DARK_TEXT);
  doc.text(`Hasil skrining kesehatan jiwa untuk ${screening.nama}`, margin, y);
  y += 8;

  // Data Demografi heading + grid
  y = drawSectionHeading(doc, "Data Demografi", y, margin);
  y = drawDemographicGrid(doc, screening, y, margin);

  // Questionnaire answers
  y = drawAnswersSection(doc, screening, y, margin);

  // Scores
  y = drawScoreSection(doc, screening, y, margin);

  // Interpretation
  y = drawSectionHeading(doc, "Interpretasi", y, margin);
  y = drawAccentBox(doc, screening.interpretasi ?? "-", y, margin);

  // Recommendation
  y = drawSectionHeading(doc, "Rekomendasi Tindak Lanjut", y, margin);
  y = drawAccentBox(doc, screening.rekomendasi ?? "-", y, margin);

  // Footer
  y = ensureSpace(doc, y, 16, margin);
  renderPdfFooter(doc, y, margin);

  const safeName = screening.nama.replace(/[^a-zA-Z0-9 ]/g, "").replace(/\s+/g, "_");
  doc.save(`Hasil_Skrining_${safeName}.pdf`);
}

/** Generate a full PDF for a patient (admin) — delegates to the shared screening result PDF generator */
export async function generateDemographicPdf(patient: ScreeningRow): Promise<void> {
  return generateScreeningResultPdf(patient);
}
