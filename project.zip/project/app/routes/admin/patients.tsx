import { useEffect, useState } from "react";
import { useNavigate, Link, useRevalidator, useSearchParams } from "react-router";
import { Button } from "~/components/ui/button/button";
import { Badge } from "~/components/ui/badge/badge";
import { Input } from "~/components/ui/input/input";
import { Label } from "~/components/ui/label/label";
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
  TableCell,
} from "~/components/ui/table/table";
import { PageTransition } from "~/components/page-transition/page-transition";
import { getScreeningsByType } from "~/services/screening-service";
import type { ScreeningRow } from "~/services/screening-service";
import { ArrowLeft, Trash2, Eye, LogOut, Download, Calendar } from "lucide-react";
import { buildScreeningExcelData, getExcelFilename } from "~/utils/export-excel";
import type { Route } from "./+types/patients";
import styles from "./patients.module.css";

const TYPE_LABELS: Record<string, string> = {
  MMYS_7_9: "MMYS V.1 — Anak (7-9 tahun)",
  MMYS_10_18: "MMYS V.1 — Remaja (10-18 tahun)",
  PHQ4: "PHQ-4 — Dewasa (≥18 tahun)",
  EPDS: "EPDS — Ibu Hamil/Nifas",
};

export async function loader({ request }: Route.LoaderArgs) {
  const url = new URL(request.url);
  const type = url.searchParams.get("type") || "MMYS_7_9";
  const from = url.searchParams.get("from") || undefined;
  const to = url.searchParams.get("to") || undefined;

  const dateRange = from || to ? { from, to } : undefined;
  const patients = await getScreeningsByType(type, dateRange);
  return { patients, type, from: from ?? "", to: to ?? "" };
}

export default function AdminPatientsPage({ loaderData }: Route.ComponentProps) {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { patients, type, from, to } = loaderData;
  const { revalidate } = useRevalidator();
  const [deleting, setDeleting] = useState<number | null>(null);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem("admin_auth") !== "true") {
      navigate("/admin/login");
    }
  }, [navigate]);

  const title = TYPE_LABELS[type] || "Daftar Pasien";
  const hasDateFilter = from || to;

  function handleDateChange(field: "from" | "to", value: string) {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set(field, value);
    } else {
      params.delete(field);
    }
    setSearchParams(params);
  }

  function handleClearDate() {
    const params = new URLSearchParams(searchParams);
    params.delete("from");
    params.delete("to");
    setSearchParams(params);
  }

  async function handleExportExcel() {
    if (patients.length === 0) return;
    setExporting(true);
    try {
      const XLSX = await import("xlsx");
      const data = buildScreeningExcelData(patients, type);
      const worksheet = XLSX.utils.json_to_sheet(data);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Data Skrining");

      /* auto-size columns */
      const colWidths = Object.keys(data[0]).map((key) => {
        const maxLen = Math.max(
          key.length,
          ...data.map((row) => String((row as Record<string, unknown>)[key] ?? "").length)
        );
        return { wch: Math.min(maxLen + 2, 50) };
      });
      worksheet["!cols"] = colWidths;

      XLSX.writeFile(workbook, getExcelFilename(type));
    } catch {
      alert("Gagal mengekspor data ke Excel.");
    } finally {
      setExporting(false);
    }
  }

  async function handleDelete(id: number, name: string) {
    if (!confirm(`Hapus data pasien "${name}"?`)) return;

    setDeleting(id);
    try {
      const response = await fetch("/api/screening", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (!response.ok) throw new Error("Gagal menghapus data");
      revalidate();
    } catch {
      alert("Gagal menghapus data pasien.");
    } finally {
      setDeleting(null);
    }
  }

  function handleLogout() {
    sessionStorage.removeItem("admin_auth");
    navigate("/admin/login");
  }

  return (
    <PageTransition className={styles.page}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <Link to="/" className={styles.logo}>SSKJD</Link>
          <span className={styles.headerTitle}>Admin</span>
        </div>
        <Button variant="outline" size="sm" onClick={handleLogout} style={{ color: "inherit", borderColor: "rgba(255,255,255,0.4)" }}>
          <LogOut size={16} style={{ marginRight: "var(--space-1)" }} />
          Keluar
        </Button>
      </header>

      <main className={styles.main}>
        <div className={styles.topBar}>
          <div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/admin/dashboard")}
              style={{ marginBottom: "var(--space-2)" }}
            >
              <ArrowLeft size={16} style={{ marginRight: "var(--space-1)" }} />
              Kembali
            </Button>
            <h1 className={styles.pageTitle}>{title}</h1>
          </div>
        </div>

        {/* Date Filter */}
        <div className={styles.dateFilterCard}>
          <div className={styles.dateFilterHeader}>
            <Calendar size={18} />
            <span className={styles.dateFilterLabel}>Filter Rentang Tanggal</span>
          </div>
          <div className={styles.dateFilterRow}>
            <div className={styles.dateField}>
              <Label htmlFor="dateFrom">Dari</Label>
              <Input
                id="dateFrom"
                type="date"
                value={from}
                onChange={(e) => handleDateChange("from", e.target.value)}
              />
            </div>
            <div className={styles.dateField}>
              <Label htmlFor="dateTo">Sampai</Label>
              <Input
                id="dateTo"
                type="date"
                value={to}
                onChange={(e) => handleDateChange("to", e.target.value)}
              />
            </div>
            {hasDateFilter && (
              <Button variant="outline" size="sm" onClick={handleClearDate} className={styles.clearDateBtn}>
                Hapus Filter
              </Button>
            )}
          </div>
          {hasDateFilter && (
            <p className={styles.dateFilterInfo}>
              Menampilkan data{from ? ` dari ${new Date(from).toLocaleDateString("id-ID")}` : ""}{to ? ` sampai ${new Date(to).toLocaleDateString("id-ID")}` : ""}
            </p>
          )}
        </div>

        {/* Action Buttons */}
        {patients.length > 0 && (
          <div className={styles.actionButtons}>
            <Button variant="outline" size="sm" onClick={handleExportExcel} disabled={exporting}>
              <Download size={16} style={{ marginRight: "var(--space-1)" }} />
              {exporting ? "Mengekspor..." : "Export Excel"}
            </Button>
          </div>
        )}

        {patients.length === 0 ? (
          <div className={styles.emptyState}>
            <p>Belum ada data pasien untuk kelompok ini{hasDateFilter ? " pada rentang tanggal yang dipilih" : ""}.</p>
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className={styles.tableWrapper}>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>No</TableHead>
                    <TableHead>Nama Lengkap</TableHead>
                    <TableHead>Usia</TableHead>
                    <TableHead>Jenis Kelamin</TableHead>
                    <TableHead>Tanggal Skrining</TableHead>
                    <TableHead>Interpretasi</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {patients.map((patient, index) => (
                    <TableRow key={patient.id} className={styles.clickableRow}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{patient.nama}</TableCell>
                      <TableCell>{patient.usia} thn</TableCell>
                      <TableCell>{patient.jenis_kelamin}</TableCell>
                      <TableCell>{new Date(patient.created_at).toLocaleDateString("id-ID")}</TableCell>
                      <TableCell>
                        <InterpretationBadge interpretasi={patient.interpretasi} />
                      </TableCell>
                      <TableCell>
                        <div className={styles.rowActions}>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => navigate(`/admin/patient-detail?id=${patient.id}`)}
                            title="Lihat Detail"
                          >
                            <Eye size={16} />
                          </Button>
                          <Button
                            variant="destructive"
                            size="icon"
                            onClick={() => handleDelete(patient.id, patient.nama)}
                            disabled={deleting === patient.id}
                            title="Hapus"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile card list */}
            <div className={styles.mobileCardList}>
              {patients.map((patient, index) => (
                <div key={patient.id} className={styles.mobileCard}>
                  <div className={styles.mobileCardHeader}>
                    <span className={styles.mobileCardNumber}>{index + 1}</span>
                    <span className={styles.mobileCardName}>{patient.nama}</span>
                    <div className={styles.mobileCardActions}>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => navigate(`/admin/patient-detail?id=${patient.id}`)}
                        title="Lihat Detail"
                      >
                        <Eye size={16} />
                      </Button>
                      <Button
                        variant="destructive"
                        size="icon"
                        onClick={() => handleDelete(patient.id, patient.nama)}
                        disabled={deleting === patient.id}
                        title="Hapus"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                  <div className={styles.mobileCardDetails}>
                    <div className={styles.mobileCardDetail}>
                      <span className={styles.mobileCardDetailLabel}>Usia</span>
                      <span className={styles.mobileCardDetailValue}>{patient.usia} thn</span>
                    </div>
                    <div className={styles.mobileCardDetail}>
                      <span className={styles.mobileCardDetailLabel}>Jenis Kelamin</span>
                      <span className={styles.mobileCardDetailValue}>{patient.jenis_kelamin}</span>
                    </div>
                    <div className={styles.mobileCardDetail}>
                      <span className={styles.mobileCardDetailLabel}>Tanggal Skrining</span>
                      <span className={styles.mobileCardDetailValue}>{new Date(patient.created_at).toLocaleDateString("id-ID")}</span>
                    </div>
                  </div>
                  <div className={styles.mobileCardInterpretation}>
                    <span className={styles.mobileCardDetailLabel}>Interpretasi</span>
                    <InterpretationBadge interpretasi={patient.interpretasi} />
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </main>
    </PageTransition>
  );
}

function InterpretationBadge({ interpretasi }: { interpretasi: string | null }) {
  const text = interpretasi ?? "";
  const isNormal = text.toLowerCase().includes("tidak");

  return (
    <Badge
      variant={isNormal ? "secondary" : "destructive"}
      className={styles.interpretationBadge}
      title={text}
    >
      <span className={styles.interpretationText}>{text || "-"}</span>
    </Badge>
  );
}
