import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router";
import { Card, CardContent } from "~/components/ui/card/card";
import { Button } from "~/components/ui/button/button";
import { PageTransition } from "~/components/page-transition/page-transition";
import { getScreeningById } from "~/services/screening-service";
import type { ScreeningRow } from "~/services/screening-service";
import { ArrowLeft, Trash2, LogOut, FileDown } from "lucide-react";
import { mmysAnxietasQuestions, mmysDepresiQuestions, phq4Questions, phq4Options, epdsQuestions } from "~/data/screening-questions";
import type { Route } from "./+types/patient-detail";
import styles from "./patient-detail.module.css";

const SCREENING_LABELS: Record<string, string> = {
  MMYS_7_9: "MMYS V.1 (Anak 7-9 tahun)",
  MMYS_10_18: "MMYS V.1 (Remaja 10-18 tahun)",
  PHQ4: "PHQ-4 (Dewasa ≥18 tahun)",
  EPDS: "EPDS (Ibu Hamil/Nifas)",
};

export async function loader({ request }: Route.LoaderArgs) {
  const url = new URL(request.url);
  const id = url.searchParams.get("id");
  if (!id) return { patient: null };

  const patient = await getScreeningById(Number(id));
  return { patient };
}

export default function PatientDetailPage({ loaderData }: Route.ComponentProps) {
  const navigate = useNavigate();
  const { patient } = loaderData;
  const [deleting, setDeleting] = useState(false);
  const [downloadingDemo, setDownloadingDemo] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem("admin_auth") !== "true") {
      navigate("/admin/login");
    }
  }, [navigate]);

  if (!patient) {
    return (
      <div className={styles.page}>
        <main className={styles.main}>
          <Card>
            <CardContent>
              <p>Data pasien tidak ditemukan.</p>
              <Button onClick={() => navigate("/admin/dashboard")} style={{ marginTop: "var(--space-4)" }}>
                Kembali ke Dashboard
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  async function handleDelete() {
    if (!patient) return;
    if (!confirm(`Hapus data pasien "${patient.nama}"?`)) return;

    setDeleting(true);
    try {
      const response = await fetch("/api/screening", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: patient.id }),
      });
      if (!response.ok) throw new Error("Gagal menghapus");
      navigate(`/admin/patients?type=${patient.jenis_instrumen}`);
    } catch {
      alert("Gagal menghapus data pasien.");
      setDeleting(false);
    }
  }

  async function handleDownloadDemographic() {
    if (!patient) return;
    setDownloadingDemo(true);
    try {
      const { generateDemographicPdf } = await import("~/utils/export-pdf");
      await generateDemographicPdf(patient);
    } catch {
      alert("Gagal mengunduh PDF demografi.");
    } finally {
      setDownloadingDemo(false);
    }
  }

  function handleLogout() {
    sessionStorage.removeItem("admin_auth");
    navigate("/admin/login");
  }

  const detail = patient.detail_jawaban as Record<string, unknown> | null;
  const tanggalSkrining = detail?.tanggal_skrining as string | undefined;
  const tempatSkrining = detail?.tempat_skrining as string | undefined;

  const hasWarning = getHasWarning(patient);

  return (
    <PageTransition className={styles.page}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <Link to="/" className={styles.logo}>SSKJD</Link>
          <span className={styles.headerTitle}>Detail Pasien</span>
        </div>
        <Button variant="outline" size="sm" onClick={handleLogout} style={{ color: "inherit", borderColor: "rgba(255,255,255,0.4)" }}>
          <LogOut size={16} style={{ marginRight: "var(--space-1)" }} />
          Keluar
        </Button>
      </header>

      <main className={styles.main}>
        <div className={styles.topBar}>
          <div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/admin/patients?type=${patient.jenis_instrumen}`)}
              style={{ marginBottom: "var(--space-2)" }}
            >
              <ArrowLeft size={16} style={{ marginRight: "var(--space-1)" }} />
              Kembali
            </Button>
            <h1 className={styles.pageTitle}>{patient.nama}</h1>
          </div>
        </div>

        {/* Demographics */}
        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Data Demografi</h2>
            <Button variant="outline" size="sm" onClick={handleDownloadDemographic} disabled={downloadingDemo}>
              <FileDown size={16} style={{ marginRight: "var(--space-1)" }} />
              {downloadingDemo ? "Mengunduh..." : "Download PDF"}
            </Button>
          </div>
          <Card>
            <CardContent>
              <div className={styles.infoGrid}>
                <div>
                  <p className={styles.infoLabel}>NIK</p>
                  <p className={styles.infoValue}>{patient.nik}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Tanggal Lahir</p>
                  <p className={styles.infoValue}>{patient.tgl_lahir ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Usia</p>
                  <p className={styles.infoValue}>{patient.usia} tahun</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Jenis Kelamin</p>
                  <p className={styles.infoValue}>{patient.jenis_kelamin}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Alamat</p>
                  <p className={styles.infoValue}>{patient.alamat ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Desa</p>
                  <p className={styles.infoValue}>{patient.desa ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Kecamatan</p>
                  <p className={styles.infoValue}>{patient.kecamatan ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Pendidikan</p>
                  <p className={styles.infoValue}>{patient.pendidikan ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Pekerjaan</p>
                  <p className={styles.infoValue}>{patient.pekerjaan ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Nomor HP</p>
                  <p className={styles.infoValue}>{patient.no_hp ?? "-"}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Tanggal Skrining</p>
                  <p className={styles.infoValue}>{tanggalSkrining ?? new Date(patient.created_at).toLocaleDateString("id-ID")}</p>
                </div>
                <div>
                  <p className={styles.infoLabel}>Tempat Skrining</p>
                  <p className={styles.infoValue}>{tempatSkrining ?? "-"}</p>
                </div>
                {patient.status_hamil_nifas !== null && (
                  <div>
                    <p className={styles.infoLabel}>Hamil/Nifas</p>
                    <p className={styles.infoValue}>{patient.status_hamil_nifas ? "Ya" : "Tidak"}</p>
                  </div>
                )}
                <div>
                  <p className={styles.infoLabel}>Jenis Skrining</p>
                  <p className={styles.infoValue}>{SCREENING_LABELS[patient.jenis_instrumen ?? ""] ?? patient.jenis_instrumen}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Answers */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Jawaban Kuesioner</h2>
          <Card>
            <CardContent>
              <div className={styles.answerList}>
                {renderAnswers(patient)}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Scores */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Skor</h2>
          <div className={styles.scoreGrid}>
            {renderScores(patient)}
          </div>
        </div>

        {/* Interpretation */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Interpretasi</h2>
          <div className={hasWarning ? styles.interpretationWarning : styles.interpretationNormal}>
            {patient.interpretasi}
          </div>
        </div>

        {/* Recommendation */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Rekomendasi Tindak Lanjut</h2>
          <div className={styles.recommendationBox}>
            <p className={styles.recommendationText}>{patient.rekomendasi}</p>
          </div>
        </div>

        <div className={styles.actions}>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={deleting}
          >
            <Trash2 size={16} style={{ marginRight: "var(--space-2)" }} />
            {deleting ? "Menghapus..." : "Hapus Data Pasien"}
          </Button>
        </div>
      </main>
    </PageTransition>
  );
}

function getHasWarning(patient: ScreeningRow): boolean {
  const type = patient.jenis_instrumen;
  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    const interp = patient.interpretasi ?? "";
    return interp.includes("ringan") || interp.includes("berat");
  }
  if (type === "PHQ4") {
    return (patient.skor_sub_depresi ?? 0) >= 3 || (patient.skor_sub_anxietas ?? 0) >= 3;
  }
  if (type === "EPDS") {
    return (patient.skor_total ?? 0) >= 13 || patient.risiko_tinggi_suicide === true;
  }
  return false;
}

function renderScores(patient: ScreeningRow) {
  const type = patient.jenis_instrumen;

  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    return (
      <>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>Skor Anxietas</p>
          <p className={styles.scoreNumber}>{patient.skor_sub_anxietas ?? 0}/3</p>
        </div>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>Skor Depresi</p>
          <p className={styles.scoreNumber}>{patient.skor_sub_depresi ?? 0}/3</p>
        </div>
      </>
    );
  }

  if (type === "PHQ4") {
    return (
      <>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>PHQ-2 (Depresi)</p>
          <p className={styles.scoreNumber}>{patient.skor_sub_depresi ?? 0}/6</p>
        </div>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>GAD-2 (Kecemasan)</p>
          <p className={styles.scoreNumber}>{patient.skor_sub_anxietas ?? 0}/6</p>
        </div>
      </>
    );
  }

  if (type === "EPDS") {
    return (
      <div className={styles.scoreBox}>
        <p className={styles.scoreLabel}>Skor EPDS</p>
        <p className={styles.scoreNumber}>{patient.skor_total ?? 0}/30</p>
      </div>
    );
  }

  return null;
}

function renderAnswers(patient: ScreeningRow) {
  const type = patient.jenis_instrumen;
  const detail = patient.detail_jawaban as Record<string, unknown> | null;
  const answers = detail?.answers as Record<string, unknown> | null;

  if (!answers) {
    return <p>Data jawaban tidak tersedia.</p>;
  }

  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    const allQuestions = [
      ...mmysAnxietasQuestions.map((q, i) => ({
        label: `A${i + 1}: ${q.text}`,
        value: answers[q.id] ? "Ya" : "Tidak",
      })),
      ...mmysDepresiQuestions.map((q, i) => ({
        label: `B${i + 1}: ${q.text}`,
        value: answers[q.id] ? "Ya" : "Tidak",
      })),
    ];
    return allQuestions.map((q, i) => (
      <div key={i} className={styles.answerItem}>
        <span>{q.label}</span>
        <span className={styles.answerValue}>{q.value}</span>
      </div>
    ));
  }

  if (type === "PHQ4") {
    return phq4Questions.map((q, i) => {
      const val = answers[q.id] as number;
      const label = phq4Options.find((o) => o.value === val)?.label || String(val);
      return (
        <div key={i} className={styles.answerItem}>
          <span>{`Q${i + 1}: ${q.text}`}</span>
          <span className={styles.answerValue}>{label} ({val})</span>
        </div>
      );
    });
  }

  if (type === "EPDS") {
    return epdsQuestions.map((q, i) => {
      const val = answers[q.id] as number;
      const optionLabel = q.options.find((o) => o.value === val)?.label || String(val);
      return (
        <div key={i} className={styles.answerItem}>
          <span>{`Q${i + 1}: ${q.text}`}</span>
          <span className={styles.answerValue}>{optionLabel} ({val})</span>
        </div>
      );
    });
  }

  return null;
}
