import { useEffect } from "react";
import { useNavigate, Link, useSearchParams } from "react-router";
import { Button } from "~/components/ui/button/button";
import { Input } from "~/components/ui/input/input";
import { Label } from "~/components/ui/label/label";
import { PageTransition } from "~/components/page-transition/page-transition";
import { getScreeningCounts } from "~/services/screening-service";
import { Baby, Users, Heart, UserRound, LogOut, Calendar } from "lucide-react";
import type { Route } from "./+types/dashboard";
import styles from "./dashboard.module.css";

export async function loader({ request }: Route.LoaderArgs) {
  const url = new URL(request.url);
  const from = url.searchParams.get("from") || undefined;
  const to = url.searchParams.get("to") || undefined;

  const dateRange = from || to ? { from, to } : undefined;
  const counts = await getScreeningCounts(dateRange);
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  return { counts, total, from: from ?? "", to: to ?? "" };
}

export default function AdminDashboardPage({ loaderData }: Route.ComponentProps) {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { counts, total, from, to } = loaderData;

  useEffect(() => {
    if (sessionStorage.getItem("admin_auth") !== "true") {
      navigate("/admin/login");
    }
  }, [navigate]);

  function handleLogout() {
    sessionStorage.removeItem("admin_auth");
    navigate("/admin/login");
  }

  function handleDateChange(field: "from" | "to", value: string) {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set(field, value);
    } else {
      params.delete(field);
    }
    setSearchParams(params);
  }

  function handleClearDate() {
    const params = new URLSearchParams(searchParams);
    params.delete("from");
    params.delete("to");
    setSearchParams(params);
  }

  function buildPatientLink(type: string): string {
    const params = new URLSearchParams();
    params.set("type", type);
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    return `/admin/patients?${params.toString()}`;
  }

  const hasDateFilter = from || to;

  const groups = [
    {
      type: "MMYS_7_9",
      title: "MMYS V.1 — Anak (7-9 tahun)",
      count: counts.MMYS_7_9,
      icon: <Baby size={32} />,
      iconClass: styles.groupIconBlue,
    },
    {
      type: "MMYS_10_18",
      title: "MMYS V.1 — Remaja (10-18 tahun)",
      count: counts.MMYS_10_18,
      icon: <UserRound size={32} />,
      iconClass: styles.groupIconGreen,
    },
    {
      type: "PHQ4",
      title: "PHQ-4 — Dewasa (≥18 tahun)",
      count: counts.PHQ4,
      icon: <Users size={32} />,
      iconClass: styles.groupIconPurple,
    },
    {
      type: "EPDS",
      title: "EPDS — Ibu Hamil/Nifas",
      count: counts.EPDS,
      icon: <Heart size={32} />,
      iconClass: styles.groupIconPink,
    },
  ];

  return (
    <PageTransition className={styles.page}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <Link to="/" className={styles.logo}>SSKJD</Link>
          <span className={styles.headerTitle}>Dashboard Admin</span>
        </div>
        <Button variant="outline" size="sm" onClick={handleLogout} style={{ color: "inherit", borderColor: "rgba(255,255,255,0.4)" }}>
          <LogOut size={16} style={{ marginRight: "var(--space-1)" }} />
          Keluar
        </Button>
      </header>

      <main className={styles.main}>
        <h1 className={styles.pageTitle}>Dashboard</h1>
        <p className={styles.pageDescription}>
          Ringkasan data skrining kesehatan jiwa.
        </p>

        <div className={styles.dateFilterCard}>
          <div className={styles.dateFilterHeader}>
            <Calendar size={18} />
            <span className={styles.dateFilterLabel}>Filter Rentang Tanggal</span>
          </div>
          <div className={styles.dateFilterRow}>
            <div className={styles.dateField}>
              <Label htmlFor="dateFrom">Dari</Label>
              <Input
                id="dateFrom"
                type="date"
                value={from}
                onChange={(e) => handleDateChange("from", e.target.value)}
              />
            </div>
            <div className={styles.dateField}>
              <Label htmlFor="dateTo">Sampai</Label>
              <Input
                id="dateTo"
                type="date"
                value={to}
                onChange={(e) => handleDateChange("to", e.target.value)}
              />
            </div>
            {hasDateFilter && (
              <Button variant="outline" size="sm" onClick={handleClearDate} className={styles.clearDateBtn}>
                Hapus Filter
              </Button>
            )}
          </div>
          {hasDateFilter && (
            <p className={styles.dateFilterInfo}>
              Menampilkan data{from ? ` dari ${new Date(from).toLocaleDateString("id-ID")}` : ""}{to ? ` sampai ${new Date(to).toLocaleDateString("id-ID")}` : ""}
            </p>
          )}
        </div>

        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <p className={styles.statNumber}>{total}</p>
            <p className={styles.statLabel}>Total Pasien</p>
          </div>
          <div className={styles.statCard}>
            <p className={styles.statNumber}>{counts.MMYS_7_9 + counts.MMYS_10_18}</p>
            <p className={styles.statLabel}>Anak &amp; Remaja</p>
          </div>
          <div className={styles.statCard}>
            <p className={styles.statNumber}>{counts.PHQ4}</p>
            <p className={styles.statLabel}>Dewasa/Lansia</p>
          </div>
          <div className={styles.statCard}>
            <p className={styles.statNumber}>{counts.EPDS}</p>
            <p className={styles.statLabel}>Ibu Hamil/Nifas</p>
          </div>
        </div>

        <h2 style={{ font: "var(--font-subheading)", color: "var(--color-neutral-12)", margin: "0 0 var(--space-4)" }}>
          Kelompok Skrining
        </h2>

        <div className={styles.groupGrid}>
          {groups.map((group) => (
            <Link
              key={group.type}
              to={buildPatientLink(group.type)}
              className={styles.groupCard}
            >
              <div className={group.iconClass}>{group.icon}</div>
              <p className={styles.groupTitle}>{group.title}</p>
              <p className={styles.groupCount}>{group.count}</p>
              <p className={styles.groupCountLabel}>pasien</p>
            </Link>
          ))}
        </div>
      </main>
    </PageTransition>
  );
}
