import { insertScreening, deleteScreening } from "~/services/screening-service";
import type { Route } from "./+types/screening";

export async function action({ request }: Route.ActionArgs) {
  if (request.method === "POST") {
    try {
      const data = await request.json();
      const row = await insertScreening(data);
      return Response.json({ id: row.id }, { status: 201 });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      return Response.json({ error: message }, { status: 500 });
    }
  }

  if (request.method === "DELETE") {
    try {
      const { id } = await request.json();
      await deleteScreening(Number(id));
      return Response.json({ success: true });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      return Response.json({ error: message }, { status: 500 });
    }
  }

  return Response.json({ error: "Method not allowed" }, { status: 405 });
}
