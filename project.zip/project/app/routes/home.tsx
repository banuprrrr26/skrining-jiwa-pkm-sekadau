import { Link } from "react-router";
import type { Route } from "./+types/home";
import { PageTransition } from "~/components/page-transition/page-transition";
import styles from "./home.module.css";
import { ClipboardList, Lock } from "lucide-react";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "SSKJD - Sistem Skrining Kesehatan Jiwa Dinamis" },
    {
      name: "description",
      content: "Sistem skrining kesehatan jiwa untuk berbagai kelompok usia",
    },
  ];
}

export default function Home() {
  return (
    <PageTransition className={styles.home}>
      <header className={styles.header}>
        <h1 className={styles.title}>Sistem Skrining Kesehatan Jiwa Dinamis</h1>
        <p className={styles.subtitle}>Platform skrining kesehatan jiwa yang komprehensif untuk semua kelompok usia</p>
      </header>

      <main className={styles.main}>
        <div className={styles.cardGrid}>
          <Link to="/screening/demographic" className={styles.optionCard}>
            <div className={styles.iconWrapper}>
              <ClipboardList />
            </div>
            <h2 className={styles.cardTitle}>Skrining Pasien</h2>
            <p className={styles.cardDescription}>
              Mulai proses skrining kesehatan jiwa dengan mengisi data diri dan menjawab kuesioner yang sesuai
            </p>
          </Link>

          <Link to="/admin/login" className={styles.optionCard}>
            <div className={styles.iconWrapper}>
              <Lock />
            </div>
            <h2 className={styles.cardTitle}>Login Admin</h2>
            <p className={styles.cardDescription}>
              Akses dashboard administrator untuk mengelola data pasien dan melihat laporan skrining
            </p>
          </Link>
        </div>
      </main>

      <footer className={styles.footer}>
        <p className={styles.footerText}>© 2025 Sistem Skrining Kesehatan Jiwa Dinamis. Semua hak dilindungi.</p>
      </footer>
    </PageTransition>
  );
}
