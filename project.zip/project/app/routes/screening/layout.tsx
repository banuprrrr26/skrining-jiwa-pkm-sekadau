import { Outlet } from "react-router";
import { ScreeningProvider } from "~/context/screening-context";
import { PageTransition } from "~/components/page-transition/page-transition";
import styles from "./layout.module.css";

export default function ScreeningLayout() {
  return (
    <ScreeningProvider>
      <div className={styles.layout}>
        <header className={styles.header}>
          <a href="/" className={styles.logo}>SSKJD</a>
          <span className={styles.headerTitle}>Skrining Kesehatan Jiwa</span>
        </header>
        <main className={styles.main}>
          <PageTransition>
            <Outlet />
          </PageTransition>
        </main>
      </div>
    </ScreeningProvider>
  );
}
