import { useState } from "react";
import { useNavigate } from "react-router";
import { Card, CardContent } from "~/components/ui/card/card";
import { Button } from "~/components/ui/button/button";
import { useScreening } from "~/context/screening-context";
import { epdsQuestions } from "~/data/screening-questions";
import { calculateEPDSScore, interpretEPDS } from "~/utils/screening-logic";
import type { EPDSAnswer } from "~/data/mock-patients";
import type { InsertScreeningData } from "~/services/screening-service";
import styles from "./questionnaire.module.css";

export default function EPDSPage() {
  const navigate = useNavigate();
  const { demographic, screeningType } = useScreening();

  const [answers, setAnswers] = useState<Record<string, number | undefined>>({});
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!demographic || !screeningType) {
    return (
      <div className={styles.container}>
        <Card>
          <CardContent>
            <p>Data demografi belum diisi. Silakan kembali ke halaman awal.</p>
            <Button onClick={() => navigate("/screening/demographic")} style={{ marginTop: "var(--space-4)" }}>
              Kembali ke Form Demografi
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  function handleAnswer(questionId: string, value: number) {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
    setError("");
  }

  async function handleSubmit() {
    if (!demographic || !screeningType) return;

    const unanswered = epdsQuestions.filter((q) => answers[q.id] === undefined);
    if (unanswered.length > 0) {
      setError("Harap jawab semua pertanyaan sebelum melanjutkan.");
      return;
    }

    const epdsAnswers: EPDSAnswer = {
      q1: answers.q1!,
      q2: answers.q2!,
      q3: answers.q3!,
      q4: answers.q4!,
      q5: answers.q5!,
      q6: answers.q6!,
      q7: answers.q7!,
      q8: answers.q8!,
      q9: answers.q9!,
      q10: answers.q10!,
    };

    const scores = calculateEPDSScore(epdsAnswers);
    const interpretation = interpretEPDS(scores, epdsAnswers.q10);
    const hasSuicideRisk = epdsAnswers.q10 >= 1;

    const payload: InsertScreeningData = {
      nama: demographic.namaLengkap,
      nik: demographic.nik,
      tgl_lahir: demographic.tanggalLahir,
      usia: demographic.usia,
      jenis_kelamin: demographic.jenisKelamin,
      alamat: demographic.alamatDomisili,
      desa: demographic.desaDomisili,
      kecamatan: demographic.kecamatanDomisili,
      pendidikan: demographic.pendidikanTerakhir,
      pekerjaan: demographic.pekerjaan,
      no_hp: demographic.nomorHP,
      status_hamil_nifas: demographic.sedangHamilNifas ?? true,
      jenis_instrumen: "EPDS",
      skor_total: scores.epdsScore,
      skor_sub_anxietas: 0,
      skor_sub_depresi: scores.epdsScore,
      interpretasi: interpretation.interpretation,
      rekomendasi: interpretation.recommendation,
      risiko_tinggi_suicide: hasSuicideRisk,
      detail_jawaban: {
        type: "EPDS",
        answers: epdsAnswers,
        tanggal_skrining: demographic.tanggalSkrining,
        tempat_skrining: demographic.tempatSkrining,
      },
    };

    setSubmitting(true);
    try {
      const response = await fetch("/api/screening", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Gagal menyimpan data");
      navigate(`/screening/result?id=${result.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menyimpan data skrining.");
      setSubmitting(false);
    }
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Edinburgh Postnatal Depression Scale (EPDS)</h1>
      <p className={styles.subtitle}>
        {`Untuk Ibu Hamil/Nifas (${demographic.namaLengkap}, ${demographic.usia} tahun)`}
      </p>
      <p className={styles.subtitle}>
        Karena Anda baru melahirkan/sedang hamil, kami ingin mengetahui perasaan Anda. Silakan pilih jawaban yang
        paling sesuai dengan perasaan Anda dalam 7 hari terakhir.
      </p>

      {error && <div className={styles.errorBanner}>{error}</div>}

      <Card>
        <CardContent>
          {epdsQuestions.map((q, i) => (
            <div key={q.id} className={styles.questionCard}>
              <div className={styles.questionNumber}>Pertanyaan {i + 1}</div>
              <div className={styles.questionText}>{q.text}</div>
              <div className={styles.optionsList}>
                {q.options.map((opt) => (
                  <label
                    key={opt.value}
                    className={answers[q.id] === opt.value ? styles.optionLabelSelected : styles.optionLabel}
                  >
                    <input
                      type="radio"
                      className={styles.radioInput}
                      name={q.id}
                      value={opt.value}
                      checked={answers[q.id] === opt.value}
                      onChange={() => handleAnswer(q.id, opt.value)}
                    />
                    {opt.label}
                  </label>
                ))}
              </div>
            </div>
          ))}

          <div className={styles.actions}>
            <Button type="button" variant="outline" onClick={() => navigate("/screening/demographic")}>
              Kembali
            </Button>
            <Button onClick={handleSubmit} disabled={submitting}>
              {submitting ? "Menyimpan..." : "Lihat Hasil"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
