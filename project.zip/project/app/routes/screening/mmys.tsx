import { useState } from "react";
import { useNavigate } from "react-router";
import { Card, CardContent } from "~/components/ui/card/card";
import { Button } from "~/components/ui/button/button";
import { useScreening } from "~/context/screening-context";
import { mmysAnxietasQuestions, mmysDepresiQuestions } from "~/data/screening-questions";
import { calculateMMYSScores, interpretMMYS } from "~/utils/screening-logic";
import type { MMYSAnswer } from "~/data/mock-patients";
import type { InsertScreeningData } from "~/services/screening-service";
import styles from "./questionnaire.module.css";

export default function MMYSPage() {
  const navigate = useNavigate();
  const { demographic, screeningType } = useScreening();

  const isChild = screeningType === "MMYS_7_9";
  const filledByParent = isChild;

  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!demographic || !screeningType) {
    return (
      <div className={styles.container}>
        <Card>
          <CardContent>
            <p>Data demografi belum diisi. Silakan kembali ke halaman awal.</p>
            <Button onClick={() => navigate("/screening/demographic")} style={{ marginTop: "var(--space-4)" }}>
              Kembali ke Form Demografi
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const allQuestions = [...mmysAnxietasQuestions, ...mmysDepresiQuestions];

  function handleAnswer(questionId: string, value: string) {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
    setError("");
  }

  async function handleSubmit() {
    if (!demographic || !screeningType) return;

    const unanswered = allQuestions.filter((q) => !answers[q.id]);
    if (unanswered.length > 0) {
      setError("Harap jawab semua pertanyaan sebelum melanjutkan.");
      return;
    }

    const mmysAnswers: MMYSAnswer = {
      anxietas1: answers.anxietas1 === "Ya",
      anxietas2: answers.anxietas2 === "Ya",
      anxietas3: answers.anxietas3 === "Ya",
      depresi1: answers.depresi1 === "Ya",
      depresi2: answers.depresi2 === "Ya",
      depresi3: answers.depresi3 === "Ya",
    };

    const scores = calculateMMYSScores(mmysAnswers);
    const interpretation = interpretMMYS(scores, mmysAnswers);
    const combinedInterpretation = `Anxietas: ${interpretation.anxietasInterpretation}. Depresi: ${interpretation.depresiInterpretation}`;

    const payload: InsertScreeningData = {
      nama: demographic.namaLengkap,
      nik: demographic.nik,
      tgl_lahir: demographic.tanggalLahir,
      usia: demographic.usia,
      jenis_kelamin: demographic.jenisKelamin,
      alamat: demographic.alamatDomisili,
      desa: demographic.desaDomisili,
      kecamatan: demographic.kecamatanDomisili,
      pendidikan: demographic.pendidikanTerakhir,
      pekerjaan: demographic.pekerjaan,
      no_hp: demographic.nomorHP,
      status_hamil_nifas: demographic.sedangHamilNifas ?? false,
      jenis_instrumen: screeningType,
      skor_total: scores.anxietasScore + scores.depresiScore,
      skor_sub_anxietas: scores.anxietasScore,
      skor_sub_depresi: scores.depresiScore,
      interpretasi: combinedInterpretation,
      rekomendasi: interpretation.recommendation,
      risiko_tinggi_suicide: false,
      detail_jawaban: {
        type: screeningType,
        answers: mmysAnswers,
        tanggal_skrining: demographic.tanggalSkrining,
        tempat_skrining: demographic.tempatSkrining,
      },
    };

    setSubmitting(true);
    try {
      const response = await fetch("/api/screening", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Gagal menyimpan data");
      navigate(`/screening/result?id=${result.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menyimpan data skrining.");
      setSubmitting(false);
    }
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Mini MindHEAR Youth Scale V.1 (MMYS V.1)</h1>
      <p className={styles.subtitle}>
        {filledByParent
          ? `Untuk anak usia 7-9 tahun — Diisi oleh orang tua/pengasuh (${demographic.namaLengkap}, ${demographic.usia} tahun)`
          : `Untuk remaja usia 10-18 tahun — Diisi oleh anak/remaja (${demographic.namaLengkap}, ${demographic.usia} tahun)`}
      </p>

      {error && <div className={styles.errorBanner}>{error}</div>}

      <Card>
        <CardContent>
          <h3 className={styles.sectionTitle}>Skala A — Anxietas</h3>
          {mmysAnxietasQuestions.map((q, i) => (
            <div key={q.id} className={styles.questionCard}>
              <div className={styles.questionNumber}>Pertanyaan A{i + 1}</div>
              <div className={styles.questionText}>{filledByParent ? q.textParent : q.text}</div>
              <div className={styles.optionsRow}>
                {["Ya", "Tidak"].map((opt) => (
                  <label
                    key={opt}
                    className={answers[q.id] === opt ? styles.optionLabelSelected : styles.optionLabel}
                  >
                    <input
                      type="radio"
                      className={styles.radioInput}
                      name={q.id}
                      value={opt}
                      checked={answers[q.id] === opt}
                      onChange={() => handleAnswer(q.id, opt)}
                    />
                    {opt}
                  </label>
                ))}
              </div>
            </div>
          ))}

          <h3 className={styles.sectionTitle}>Skala B — Depresi</h3>
          {mmysDepresiQuestions.map((q, i) => (
            <div key={q.id} className={styles.questionCard}>
              <div className={styles.questionNumber}>Pertanyaan B{i + 1}</div>
              <div className={styles.questionText}>{filledByParent ? q.textParent : q.text}</div>
              <div className={styles.optionsRow}>
                {["Ya", "Tidak"].map((opt) => (
                  <label
                    key={opt}
                    className={answers[q.id] === opt ? styles.optionLabelSelected : styles.optionLabel}
                  >
                    <input
                      type="radio"
                      className={styles.radioInput}
                      name={q.id}
                      value={opt}
                      checked={answers[q.id] === opt}
                      onChange={() => handleAnswer(q.id, opt)}
                    />
                    {opt}
                  </label>
                ))}
              </div>
            </div>
          ))}

          <div className={styles.actions}>
            <Button type="button" variant="outline" onClick={() => navigate("/screening/demographic")}>
              Kembali
            </Button>
            <Button onClick={handleSubmit} disabled={submitting}>
              {submitting ? "Menyimpan..." : "Lihat Hasil"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
