import { useState } from "react";
import { useNavigate } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "~/components/ui/card/card";
import { Button } from "~/components/ui/button/button";
import { getScreeningById } from "~/services/screening-service";
import type { ScreeningRow } from "~/services/screening-service";
import { CheckCircle, AlertTriangle, Home, FileDown } from "lucide-react";
import type { Route } from "./+types/result";
import styles from "./result.module.css";

const SCREENING_LABELS: Record<string, string> = {
  MMYS_7_9: "MMYS V.1 (Anak 7-9 tahun)",
  MMYS_10_18: "MMYS V.1 (Remaja 10-18 tahun)",
  PHQ4: "PHQ-4 (Dewasa ≥18 tahun)",
  EPDS: "EPDS (Ibu Hamil/Nifas)",
};

export async function loader({ request }: Route.LoaderArgs) {
  const url = new URL(request.url);
  const id = url.searchParams.get("id");
  if (!id) return { screening: null };

  const screening = await getScreeningById(Number(id));
  return { screening };
}

export default function ResultPage({ loaderData }: Route.ComponentProps) {
  const navigate = useNavigate();
  const { screening } = loaderData;
  const [downloading, setDownloading] = useState(false);

  if (!screening) {
    return (
      <div className={styles.container}>
        <Card>
          <CardContent>
            <p>Hasil skrining tidak ditemukan.</p>
            <Button onClick={() => navigate("/")} style={{ marginTop: "var(--space-4)" }}>
              Kembali ke Beranda
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const hasWarning = getHasWarning(screening);

  async function handleDownloadPdf() {
    if (!screening) return;
    setDownloading(true);
    try {
      const { generateScreeningResultPdf } = await import("~/utils/export-pdf");
      await generateScreeningResultPdf(screening);
    } catch {
      alert("Gagal mengunduh PDF. Silakan coba lagi.");
    } finally {
      setDownloading(false);
    }
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Hasil Skrining</h1>
      <p className={styles.description}>
        Berikut adalah ringkasan hasil skrining kesehatan jiwa untuk {screening.nama}.
      </p>

      <Card className={styles.resultCard}>
        <CardHeader>
          <CardTitle>Informasi Pasien</CardTitle>
        </CardHeader>
        <CardContent>
          <div className={styles.patientInfo}>
            <div>
              <p className={styles.sectionLabel}>Nama Lengkap</p>
              <p className={styles.sectionValue}>{screening.nama}</p>
            </div>
            <div>
              <p className={styles.sectionLabel}>Usia</p>
              <p className={styles.sectionValue}>{screening.usia} tahun</p>
            </div>
            <div>
              <p className={styles.sectionLabel}>Jenis Kelamin</p>
              <p className={styles.sectionValue}>{screening.jenis_kelamin}</p>
            </div>
            <div>
              <p className={styles.sectionLabel}>Jenis Skrining</p>
              <p className={styles.sectionValue}>{SCREENING_LABELS[screening.jenis_instrumen ?? ""] ?? screening.jenis_instrumen}</p>
            </div>
            <div>
              <p className={styles.sectionLabel}>Tanggal Skrining</p>
              <p className={styles.sectionValue}>
                {getDetailValue(screening, "tanggal_skrining") ?? new Date(screening.created_at).toLocaleDateString("id-ID")}
              </p>
            </div>
            <div>
              <p className={styles.sectionLabel}>Tempat Skrining</p>
              <p className={styles.sectionValue}>
                {getDetailValue(screening, "tempat_skrining") ?? "-"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className={styles.resultCard}>
        <CardHeader>
          <CardTitle>Skor</CardTitle>
        </CardHeader>
        <CardContent>
          <div className={styles.scoreGrid}>
            {renderScores(screening)}
          </div>
        </CardContent>
      </Card>

      <div className={hasWarning ? styles.interpretationWarning : styles.interpretationNormal}>
        <p className={styles.interpretationTitle}>
          {hasWarning ? (
            <span style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
              <AlertTriangle size={20} /> Interpretasi Hasil
            </span>
          ) : (
            <span style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
              <CheckCircle size={20} /> Interpretasi Hasil
            </span>
          )}
        </p>
        <p className={styles.interpretationText}>{screening.interpretasi}</p>
      </div>

      <div className={styles.recommendationBox}>
        <p className={styles.recommendationTitle}>Rekomendasi Tindak Lanjut</p>
        <p className={styles.recommendationText}>{screening.rekomendasi}</p>
      </div>

      <div className={styles.actions}>
        <Button onClick={handleDownloadPdf} disabled={downloading}>
          <FileDown size={16} style={{ marginRight: "var(--space-2)" }} />
          {downloading ? "Mengunduh..." : "Unduh PDF"}
        </Button>
        <Button variant="outline" onClick={() => navigate("/")}>
          <Home size={16} style={{ marginRight: "var(--space-2)" }} />
          Kembali ke Beranda
        </Button>
        <Button variant="outline" onClick={() => navigate("/screening/demographic")}>
          Skrining Pasien Baru
        </Button>
      </div>
    </div>
  );
}

function getDetailValue(screening: ScreeningRow, key: string): string | null {
  const detail = screening.detail_jawaban as Record<string, unknown> | null;
  if (!detail) return null;
  const val = detail[key];
  return typeof val === "string" ? val : null;
}

function getHasWarning(screening: ScreeningRow): boolean {
  const type = screening.jenis_instrumen;
  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    const interp = screening.interpretasi ?? "";
    return interp.includes("ringan") || interp.includes("berat");
  }
  if (type === "PHQ4") {
    return (screening.skor_sub_depresi ?? 0) >= 3 || (screening.skor_sub_anxietas ?? 0) >= 3;
  }
  if (type === "EPDS") {
    return (screening.skor_total ?? 0) >= 13 || screening.risiko_tinggi_suicide === true;
  }
  return false;
}

function renderScores(screening: ScreeningRow) {
  const type = screening.jenis_instrumen;

  if (type === "MMYS_7_9" || type === "MMYS_10_18") {
    return (
      <>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>Skor Anxietas</p>
          <p className={styles.scoreNumber}>{screening.skor_sub_anxietas ?? 0}/3</p>
        </div>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>Skor Depresi</p>
          <p className={styles.scoreNumber}>{screening.skor_sub_depresi ?? 0}/3</p>
        </div>
      </>
    );
  }

  if (type === "PHQ4") {
    return (
      <>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>PHQ-2 (Depresi)</p>
          <p className={styles.scoreNumber}>{screening.skor_sub_depresi ?? 0}/6</p>
        </div>
        <div className={styles.scoreBox}>
          <p className={styles.scoreLabel}>GAD-2 (Kecemasan)</p>
          <p className={styles.scoreNumber}>{screening.skor_sub_anxietas ?? 0}/6</p>
        </div>
      </>
    );
  }

  if (type === "EPDS") {
    return (
      <div className={styles.scoreBox}>
        <p className={styles.scoreLabel}>Skor EPDS</p>
        <p className={styles.scoreNumber}>{screening.skor_total ?? 0}/30</p>
      </div>
    );
  }

  return null;
}
