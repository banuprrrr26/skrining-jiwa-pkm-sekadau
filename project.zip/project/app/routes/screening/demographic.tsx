import { useState } from "react";
import { useNavigate } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "~/components/ui/card/card";
import { Input } from "~/components/ui/input/input";
import { Label } from "~/components/ui/label/label";
import { Button } from "~/components/ui/button/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "~/components/ui/select/select";
import { useScreening } from "~/context/screening-context";
import { determineScreeningType } from "~/utils/screening-logic";
import type { PatientDemographic } from "~/data/mock-patients";
import styles from "./demographic.module.css";

function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

export default function DemographicPage() {
  const navigate = useNavigate();
  const { setDemographic, setScreeningType } = useScreening();

  const [form, setForm] = useState({
    namaLengkap: "",
    nik: "",
    tanggalLahir: "",
    jenisKelamin: "",
    alamatDomisili: "",
    desaDomisili: "",
    kecamatanDomisili: "",
    pendidikanTerakhir: "",
    pekerjaan: "",
    tanggalSkrining: new Date().toISOString().split("T")[0],
    tempatSkrining: "",
    nomorHP: "",
    sedangHamilNifas: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const age = form.tanggalLahir ? calculateAge(form.tanggalLahir) : null;
  const showPregnancyQuestion = form.jenisKelamin === "Perempuan" && age !== null && age > 12;

  function updateField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  }

  function validate(): boolean {
    const newErrors: Record<string, string> = {};

    if (!form.namaLengkap.trim()) newErrors.namaLengkap = "Nama lengkap wajib diisi";
    if (!form.nik.trim()) newErrors.nik = "NIK wajib diisi";
    else if (form.nik.length !== 16) newErrors.nik = "NIK harus 16 digit";
    if (!form.tanggalLahir) newErrors.tanggalLahir = "Tanggal lahir wajib diisi";
    if (age !== null && (age < 7 || age > 120)) newErrors.tanggalLahir = "Usia pasien harus minimal 7 tahun";
    if (!form.jenisKelamin) newErrors.jenisKelamin = "Jenis kelamin wajib dipilih";
    if (!form.alamatDomisili.trim()) newErrors.alamatDomisili = "Alamat wajib diisi";
    if (!form.desaDomisili.trim()) newErrors.desaDomisili = "Desa wajib diisi";
    if (!form.kecamatanDomisili.trim()) newErrors.kecamatanDomisili = "Kecamatan wajib diisi";
    if (!form.pendidikanTerakhir) newErrors.pendidikanTerakhir = "Pendidikan wajib dipilih";
    if (!form.pekerjaan.trim()) newErrors.pekerjaan = "Pekerjaan wajib diisi";
    if (!form.tanggalSkrining) newErrors.tanggalSkrining = "Tanggal skrining wajib diisi";
    if (!form.tempatSkrining.trim()) newErrors.tempatSkrining = "Tempat skrining wajib diisi";
    if (!form.nomorHP.trim()) newErrors.nomorHP = "Nomor HP wajib diisi";
    if (showPregnancyQuestion && !form.sedangHamilNifas) {
      newErrors.sedangHamilNifas = "Pertanyaan ini wajib dijawab";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate() || age === null) return;

    const patientId = `P${Date.now()}`;
    const isPregnantOrPostpartum = form.sedangHamilNifas === "Ya";
    const screeningType = determineScreeningType(
      age,
      form.jenisKelamin,
      isPregnantOrPostpartum
    );

    const demographic: PatientDemographic = {
      id: patientId,
      namaLengkap: form.namaLengkap,
      nik: form.nik,
      tanggalLahir: form.tanggalLahir,
      usia: age,
      jenisKelamin: form.jenisKelamin as "Laki-laki" | "Perempuan",
      alamatDomisili: form.alamatDomisili,
      desaDomisili: form.desaDomisili,
      kecamatanDomisili: form.kecamatanDomisili,
      pendidikanTerakhir: form.pendidikanTerakhir,
      pekerjaan: form.pekerjaan,
      tanggalSkrining: form.tanggalSkrining,
      tempatSkrining: form.tempatSkrining,
      nomorHP: form.nomorHP,
      sedangHamilNifas: showPregnancyQuestion ? isPregnantOrPostpartum : undefined,
    };

    setDemographic(demographic);
    setScreeningType(screeningType);

    const routeMap = {
      MMYS_7_9: "/screening/mmys",
      MMYS_10_18: "/screening/mmys",
      PHQ4: "/screening/phq4",
      EPDS: "/screening/epds",
    };

    navigate(routeMap[screeningType]);
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Data Demografi Pasien</h1>
      <p className={styles.description}>
        Silakan lengkapi data diri pasien untuk memulai skrining kesehatan jiwa.
      </p>

      <Card>
        <CardContent>
          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.fieldGroup}>
              <div className={styles.fieldFull}>
                <Label htmlFor="namaLengkap">Nama Lengkap</Label>
                <Input
                  id="namaLengkap"
                  value={form.namaLengkap}
                  onChange={(e) => updateField("namaLengkap", e.target.value)}
                  placeholder="Masukkan nama lengkap"
                />
                {errors.namaLengkap && <span className={styles.errorText}>{errors.namaLengkap}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="nik">NIK</Label>
                <Input
                  id="nik"
                  value={form.nik}
                  onChange={(e) => updateField("nik", e.target.value.replace(/\D/g, "").slice(0, 16))}
                  placeholder="16 digit NIK"
                  maxLength={16}
                />
                {errors.nik && <span className={styles.errorText}>{errors.nik}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="tanggalLahir">Tanggal Lahir</Label>
                <Input
                  id="tanggalLahir"
                  type="date"
                  value={form.tanggalLahir}
                  onChange={(e) => updateField("tanggalLahir", e.target.value)}
                />
                {errors.tanggalLahir && <span className={styles.errorText}>{errors.tanggalLahir}</span>}
                {age !== null && age >= 0 && (
                  <span style={{ font: "var(--font-caption)", color: "var(--color-accent-11)" }}>
                    Usia: {age} tahun
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <Label>Jenis Kelamin</Label>
                <Select value={form.jenisKelamin} onValueChange={(v) => updateField("jenisKelamin", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih jenis kelamin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Laki-laki">Laki-laki</SelectItem>
                    <SelectItem value="Perempuan">Perempuan</SelectItem>
                  </SelectContent>
                </Select>
                {errors.jenisKelamin && <span className={styles.errorText}>{errors.jenisKelamin}</span>}
              </div>

              <div className={styles.fieldFull}>
                <Label htmlFor="alamatDomisili">Alamat Domisili</Label>
                <Input
                  id="alamatDomisili"
                  value={form.alamatDomisili}
                  onChange={(e) => updateField("alamatDomisili", e.target.value)}
                  placeholder="Masukkan alamat lengkap"
                />
                {errors.alamatDomisili && <span className={styles.errorText}>{errors.alamatDomisili}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="desaDomisili">Desa Domisili</Label>
                <Input
                  id="desaDomisili"
                  value={form.desaDomisili}
                  onChange={(e) => updateField("desaDomisili", e.target.value)}
                  placeholder="Masukkan desa"
                />
                {errors.desaDomisili && <span className={styles.errorText}>{errors.desaDomisili}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="kecamatanDomisili">Kecamatan Domisili</Label>
                <Input
                  id="kecamatanDomisili"
                  value={form.kecamatanDomisili}
                  onChange={(e) => updateField("kecamatanDomisili", e.target.value)}
                  placeholder="Masukkan kecamatan"
                />
                {errors.kecamatanDomisili && <span className={styles.errorText}>{errors.kecamatanDomisili}</span>}
              </div>

              <div className={styles.field}>
                <Label>Pendidikan Terakhir</Label>
                <Select value={form.pendidikanTerakhir} onValueChange={(v) => updateField("pendidikanTerakhir", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih pendidikan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Tidak Sekolah">Tidak Sekolah</SelectItem>
                    <SelectItem value="SD">SD</SelectItem>
                    <SelectItem value="SMP">SMP</SelectItem>
                    <SelectItem value="SMA">SMA</SelectItem>
                    <SelectItem value="D3">D3</SelectItem>
                    <SelectItem value="S1">S1</SelectItem>
                    <SelectItem value="S2">S2</SelectItem>
                    <SelectItem value="S3">S3</SelectItem>
                  </SelectContent>
                </Select>
                {errors.pendidikanTerakhir && <span className={styles.errorText}>{errors.pendidikanTerakhir}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="pekerjaan">Pekerjaan</Label>
                <Input
                  id="pekerjaan"
                  value={form.pekerjaan}
                  onChange={(e) => updateField("pekerjaan", e.target.value)}
                  placeholder="Masukkan pekerjaan"
                />
                {errors.pekerjaan && <span className={styles.errorText}>{errors.pekerjaan}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="tanggalSkrining">Tanggal Skrining</Label>
                <Input
                  id="tanggalSkrining"
                  type="date"
                  value={form.tanggalSkrining}
                  onChange={(e) => updateField("tanggalSkrining", e.target.value)}
                />
                {errors.tanggalSkrining && <span className={styles.errorText}>{errors.tanggalSkrining}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="tempatSkrining">Tempat Skrining</Label>
                <Input
                  id="tempatSkrining"
                  value={form.tempatSkrining}
                  onChange={(e) => updateField("tempatSkrining", e.target.value)}
                  placeholder="Contoh: Puskesmas XYZ"
                />
                {errors.tempatSkrining && <span className={styles.errorText}>{errors.tempatSkrining}</span>}
              </div>

              <div className={styles.field}>
                <Label htmlFor="nomorHP">Nomor HP</Label>
                <Input
                  id="nomorHP"
                  value={form.nomorHP}
                  onChange={(e) => updateField("nomorHP", e.target.value.replace(/\D/g, ""))}
                  placeholder="Contoh: 081234567890"
                />
                {errors.nomorHP && <span className={styles.errorText}>{errors.nomorHP}</span>}
              </div>
            </div>

            {showPregnancyQuestion && (
              <div className={styles.pregnancyBox}>
                <p className={styles.pregnancyLabel}>Apakah Anda sedang hamil atau nifas?</p>
                <div className={styles.radioRow}>
                  <label className={styles.radioOption}>
                    <input
                      type="radio"
                      className={styles.radioInput}
                      name="sedangHamilNifas"
                      value="Ya"
                      checked={form.sedangHamilNifas === "Ya"}
                      onChange={(e) => updateField("sedangHamilNifas", e.target.value)}
                    />
                    Ya
                  </label>
                  <label className={styles.radioOption}>
                    <input
                      type="radio"
                      className={styles.radioInput}
                      name="sedangHamilNifas"
                      value="Tidak"
                      checked={form.sedangHamilNifas === "Tidak"}
                      onChange={(e) => updateField("sedangHamilNifas", e.target.value)}
                    />
                    Tidak
                  </label>
                </div>
                {errors.sedangHamilNifas && <span className={styles.errorText}>{errors.sedangHamilNifas}</span>}
              </div>
            )}

            <div className={styles.actions}>
              <Button type="button" variant="outline" onClick={() => navigate("/")}>
                Kembali
              </Button>
              <Button type="submit">Lanjutkan ke Kuesioner</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
