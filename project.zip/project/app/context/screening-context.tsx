import React from "react";
import type { PatientDemographic, ScreeningType } from "~/data/mock-patients";

interface ScreeningContextType {
  demographic: PatientDemographic | null;
  setDemographic: (data: PatientDemographic) => void;
  screeningType: ScreeningType | null;
  setScreeningType: (type: ScreeningType) => void;
  clearScreening: () => void;
}

const ScreeningContext = React.createContext<ScreeningContextType | undefined>(undefined);

export function ScreeningProvider({ children }: { children: React.ReactNode }) {
  const [demographic, setDemographic] = React.useState<PatientDemographic | null>(null);
  const [screeningType, setScreeningType] = React.useState<ScreeningType | null>(null);

  const clearScreening = () => {
    setDemographic(null);
    setScreeningType(null);
  };

  return (
    <ScreeningContext.Provider value={{ demographic, setDemographic, screeningType, setScreeningType, clearScreening }}>
      {children}
    </ScreeningContext.Provider>
  );
}

export function useScreening() {
  const context = React.useContext(ScreeningContext);
  if (!context) {
    throw new Error("useScreening must be used within ScreeningProvider");
  }
  return context;
}
