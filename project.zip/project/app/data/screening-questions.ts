// MMYS V.1 Questions
export const mmysAnxietasQuestions = [
  {
    id: "anxietas1",
    text: "Apakah Anda (anak) sering merasa khawatir tentang banyak hal?",
    textParent: "Apakah anak Anda sering merasa khawatir tentang banyak hal?",
  },
  {
    id: "anxietas2",
    text: "Apakah Anda (anak) pernah merasa cemas atau takut yang tidak biasa?",
    textParent: "Apakah anak Anda pernah merasa cemas atau takut yang tidak biasa?",
  },
  {
    id: "anxietas3",
    text: "Apakah rasa khawatir atau takut ini mengganggu aktivitas sehari-hari Anda (anak)?",
    textParent: "Apakah rasa khawatir atau takut ini mengganggu aktivitas sehari-hari anak Anda?",
  },
];

export const mmysDepresiQuestions = [
  {
    id: "depresi1",
    text: "Apakah Anda (anak) sering merasa sedih, murung, atau tidak bersemangat?",
    textParent: "Apakah anak Anda sering merasa sedih, murung, atau tidak bersemangat?",
  },
  {
    id: "depresi2",
    text: "Apakah Anda (anak) kehilangan minat terhadap hal-hal yang biasanya disukai?",
    textParent: "Apakah anak Anda kehilangan minat terhadap hal-hal yang biasanya disukai?",
  },
  {
    id: "depresi3",
    text: "Apakah perasaan sedih atau tidak bersemangat ini berlangsung hampir setiap hari?",
    textParent: "Apakah perasaan sedih atau tidak bersemangat ini berlangsung hampir setiap hari?",
  },
];

// PHQ-4 Questions
export const phq4Questions = [
  { id: "q1", text: "Merasa kurang berminat atau kurang senang dalam melakukan berbagai hal" },
  { id: "q2", text: "Merasa sedih, murung, atau putus asa" },
  { id: "q3", text: "Merasa gugup, cemas, atau tegang" },
  { id: "q4", text: "Tidak mampu menghentikan atau mengendalikan rasa khawatir" },
];

export const phq4Options = [
  { value: 0, label: "Tidak sama sekali" },
  { value: 1, label: "Kurang dari 1 minggu" },
  { value: 2, label: "Lebih dari 1 minggu" },
  { value: 3, label: "Hampir setiap hari" },
];

// EPDS Questions
export const epdsQuestions = [
  {
    id: "q1",
    text: "Saya bisa tertawa dan melihat sisi lucu dari berbagai hal",
    options: [
      { value: 0, label: "Sama seperti biasanya" },
      { value: 1, label: "Tidak begitu banyak sekarang" },
      { value: 2, label: "Jelas berkurang sekarang" },
      { value: 3, label: "Tidak bisa sama sekali" },
    ],
  },
  {
    id: "q2",
    text: "Saya menikmati hal-hal yang akan terjadi",
    options: [
      { value: 0, label: "Sama seperti biasanya" },
      { value: 1, label: "Agak berkurang dari biasanya" },
      { value: 2, label: "Jelas berkurang dari biasanya" },
      { value: 3, label: "Hampir tidak sama sekali" },
    ],
  },
  {
    id: "q3",
    text: "Saya menyalahkan diri sendiri jika ada yang tidak beres",
    options: [
      { value: 0, label: "Tidak, tidak pernah" },
      { value: 1, label: "Tidak terlalu sering" },
      { value: 2, label: "Ya, kadang-kadang" },
      { value: 3, label: "Ya, sering sekali" },
    ],
    reversed: true,
  },
  {
    id: "q4",
    text: "Saya merasa cemas atau khawatir tanpa alasan yang jelas",
    options: [
      { value: 0, label: "Tidak, tidak sama sekali" },
      { value: 1, label: "Hampir tidak pernah" },
      { value: 2, label: "Ya, kadang-kadang" },
      { value: 3, label: "Ya, sangat sering" },
    ],
  },
  {
    id: "q5",
    text: "Saya merasa takut atau panik tanpa alasan yang jelas",
    options: [
      { value: 0, label: "Tidak, tidak sama sekali" },
      { value: 1, label: "Tidak, tidak terlalu" },
      { value: 2, label: "Ya, kadang-kadang" },
      { value: 3, label: "Ya, cukup sering" },
    ],
    reversed: true,
  },
  {
    id: "q6",
    text: "Berbagai hal menumpuk sehingga sulit saya atasi",
    options: [
      { value: 0, label: "Tidak, saya bisa mengatasinya dengan baik" },
      { value: 1, label: "Tidak, umumnya saya bisa mengatasinya" },
      { value: 2, label: "Ya, kadang saya tidak bisa mengatasinya" },
      { value: 3, label: "Ya, sering kali saya tidak bisa mengatasinya" },
    ],
    reversed: true,
  },
  {
    id: "q7",
    text: "Saya begitu tidak bahagia sehingga saya sulit tidur",
    options: [
      { value: 0, label: "Tidak, tidak sama sekali" },
      { value: 1, label: "Tidak terlalu sering" },
      { value: 2, label: "Ya, kadang-kadang" },
      { value: 3, label: "Ya, sering sekali" },
    ],
    reversed: true,
  },
  {
    id: "q8",
    text: "Saya merasa sedih atau sengsara",
    options: [
      { value: 0, label: "Tidak, tidak sama sekali" },
      { value: 1, label: "Tidak terlalu sering" },
      { value: 2, label: "Ya, cukup sering" },
      { value: 3, label: "Ya, hampir sepanjang waktu" },
    ],
    reversed: true,
  },
  {
    id: "q9",
    text: "Saya begitu tidak bahagia sehingga saya menangis",
    options: [
      { value: 0, label: "Tidak, tidak pernah" },
      { value: 1, label: "Hanya sesekali" },
      { value: 2, label: "Ya, cukup sering" },
      { value: 3, label: "Ya, hampir sepanjang waktu" },
    ],
    reversed: true,
  },
  {
    id: "q10",
    text: "Pikiran untuk menyakiti diri sendiri muncul di benak saya",
    options: [
      { value: 0, label: "Tidak pernah" },
      { value: 1, label: "Hampir tidak pernah" },
      { value: 2, label: "Kadang-kadang" },
      { value: 3, label: "Ya, cukup sering" },
    ],
    reversed: true,
  },
];
