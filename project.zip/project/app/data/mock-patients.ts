export interface PatientDemographic {
  id: string;
  namaLengkap: string;
  nik: string;
  tanggalLahir: string;
  usia: number;
  jenisKelamin: "Laki-laki" | "Perempuan";
  alamatDomisili: string;
  desaDomisili: string;
  kecamatanDomisili: string;
  pendidikanTerakhir: string;
  pekerjaan: string;
  tanggalSkrining: string;
  tempatSkrining: string;
  nomorHP: string;
  sedangHamilNifas?: boolean;
}

export interface MMYSAnswer {
  anxietas1: boolean;
  anxietas2: boolean;
  anxietas3: boolean;
  depresi1: boolean;
  depresi2: boolean;
  depresi3: boolean;
}

export interface PHQ4Answer {
  q1: number; // 0-3
  q2: number; // 0-3
  q3: number; // 0-3
  q4: number; // 0-3
}

export interface EPDSAnswer {
  q1: number; // 0-3
  q2: number; // 0-3
  q3: number; // 0-3
  q4: number; // 0-3
  q5: number; // 0-3
  q6: number; // 0-3
  q7: number; // 0-3
  q8: number; // 0-3
  q9: number; // 0-3
  q10: number; // 0-3
}

export type ScreeningType = "MMYS_7_9" | "MMYS_10_18" | "PHQ4" | "EPDS";
