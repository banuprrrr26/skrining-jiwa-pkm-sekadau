# Code Patterns & Practices

- One class or component per file
- When creating a custom React component, create `component-name.module.css` next to it
